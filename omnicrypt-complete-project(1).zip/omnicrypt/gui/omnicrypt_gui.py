#!/usr/bin/env python3
# OmniCrypt GTK4 Modern UI Client
# Developer: NAZY-OS
# License: GNU GPL v3

import json
import os
import sys
import threading
import subprocess
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gio", "2.0")
gi.require_version("Notify", "0.7")

from gi.repository import Gio, Gtk, GLib, Notify
from pydbus import SystemBus

HAVE_APPINDICATOR = False
try:
    gi.require_version("AppIndicator3", "0.1")
    from gi.repository import AppIndicator3
    HAVE_APPINDICATOR = True
except (ValueError, ImportError):
    print("Warning: AppIndicator3 not available. System tray will be disabled.")

Notify.init("OmniCrypt")

class OmniCryptWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_title("OmniCrypt (Pro) – NAZY-OS")
        self.set_default_size(1100, 700)

        try:
            self.bus = SystemBus()
            self.proxy = self.bus.get("org.omnicrypt.Manager")
            self.proxy.onStateChanged = lambda: GLib.idle_add(self.refresh_status)
        except Exception:
            self.proxy = None

        main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.set_child(main_box)

        left_container = Gtk.Box(orientation=GK.Orientation.VERTICAL if False else Gtk.Orientation.VERTICAL, spacing=12)
        left_container.set_size_request(500, -1)
        left_container.set_margin_top(16)
        left_container.set_margin_bottom(16)
        left_container.set_margin_start(16)
        left_container.set_margin_end(8)
        main_box.append(left_container)

        action_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        left_container.append(action_bar)

        btn_ref = Gtk.Button(label="Refresh Status")
        btn_ref.add_css_class("flat")
        btn_ref.connect("clicked", lambda w: self.refresh_status())
        action_bar.append(btn_ref)

        btn_create = Gtk.Button(label="+ New Image")
        btn_create.add_css_class("suggested-action")
        action_bar.append(btn_create)

        btn_config = Gtk.Button(label="Config Manager")
        btn_config.connect("clicked", self.on_open_config_manager)
        action_bar.append(btn_config)

        btn_emergency = Gtk.Button(label="🚨 EMERGENCY LOCKDOWN")
        btn_emergency.add_css_class("destructive-action")
        btn_emergency.connect("clicked", lambda w: self.on_emergency_clicked())
        left_container.append(btn_emergency)

        self.status_label = Gtk.Label(label="System ready (NAZY-OS).", xalign=0)
        self.status_label.add_css_class("dim-label")

        scrolled = Gtk.ScrolledWindow(vexpand=True, hexpand=True)
        scrolled.add_css_class("card")
        left_container.append(scrolled)

        self.list_box = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        scrolled.set_child(self.list_box)
        left_container.append(self.status_label)

        self.setup_system_tray()
        self.refresh_status()

    def set_status(self, text):
        self.status_label.set_text(f"Info: {text}")

    def run_async(self, func, *args):
        def worker():
            try:
                func(*args)
            except Exception as e:
                GLib.idle_add(self.set_status, f"Error: {e}")
            GLib.idle_add(self.refresh_status)
        threading.Thread(target=worker, daemon=True).start()

    def refresh_status(self):
        while (row := self.list_box.get_row_at_index(0)):
            self.list_box.remove(row)
        if not self.proxy:
            self.list_box.append(Gtk.Label(label="No D-Bus connection."))
            return
        try:
            data = json.loads(self.proxy.GetStatus())
        except Exception:
            return

        for c in data.get("containers", []):
            frame = Gtk.Frame(label=f"Container: {c['mapper']}")
            frame.add_css_class("card")
            f_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
            frame.set_child(f_box)
            status_text = "Locked 🔒" if c['luks_locked'] else "Unlocked 🔓"
            info_label = Gtk.Label(label=f"Image: {c['image']}\nMount: {c['mount_point']} | Status: {status_text}", xalign=0)
            f_box.append(info_label)
            self.list_box.append(frame)

    def on_emergency_clicked(self):
        if self.proxy:
            self.run_async(self.proxy.EmergencyDismount)
            self.set_status("EMERGENCY LOCKDOWN TRIGGERED!")

    def on_open_config_manager(self, btn):
        pass

    def setup_system_tray(self):
        if not HAVE_APPINDICATOR:
            return
        try:
            self.indicator = AppIndicator3.Indicator.new(
                "omnicrypt-indicator",
                "system-lock-screen-symbolic",
                AppIndicator3.IndicatorCategory.APPLICATION_STATUS
            )
            self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)
            self.indicator.set_menu(self.build_tray_menu())
        except Exception as e:
            print(f"Failed to initialize system tray: {e}")

    def build_tray_menu(self):
        menu = Gtk.Menu()
        item_title = Gtk.MenuItem(label="OmniCrypt (NAZY-OS)")
        item_title.set_sensitive(False)
        menu.append(item_title)
        menu.append(Gtk.SeparatorMenuItem())
        
        item_emergency = Gtk.MenuItem(label="🚨 EMERGENCY LOCKDOWN")
        item_emergency.connect("activate", lambda w: self.on_emergency_clicked())
        menu.append(item_emergency)
        menu.append(Gtk.SeparatorMenuItem())

        item_show = Gtk.MenuItem(label="Show Main Window")
        item_show.connect("activate", lambda w: self.present())
        menu.append(item_show)

        item_quit = Gtk.MenuItem(label="Quit")
        item_quit.connect("activate", lambda w: Gtk.Application.quit(self.get_application()))
        menu.append(item_quit)

        menu.show_all()
        return menu

class OmniCryptApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.omnicrypt.Manager")
    def do_activate(self):
        OmniCryptWindow(application=self).present()

if __name__ == "__main__":
    sys.exit(OmniCryptApp().run(sys.argv))
