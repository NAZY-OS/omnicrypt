#!/usr/bin/env python3
# OmniCrypt D-Bus Service Backend with Dynamic State & Auto-Close Timer Support
# Developer: NAZY-OS
# License: GNU GPL v3

import os
import json
import subprocess
import threading
import time
import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib

# Path constants for background execution and configuration storage
BACKEND_SCRIPT = "/usr/libexec/omnicrypt/omnicrypt.sh"
CONFIG_FILE = "/etc/omnicrypt/config.json"

class OmniCryptService(dbus.service.Object):
    def __init__(self):
        # Register system bus service interface
        bus_name = dbus.service.BusName("org.omnicrypt.Manager", dbus.SystemBus())
        super().__init__(bus_name, "/org/omnicrypt/Manager")
        self.lock_timer = None
        self.autoclose_minutes = 15
        self.load_config()

    def load_config(self):
        # Read saved configuration parameters if present on system
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r") as f:
                    cfg = json.load(f)
                    self.autoclose_minutes = cfg.get("autoclose_minutes", 15)
        except Exception:
            pass

    def reset_inactivity_timer(self):
        # Restart background countdown for auto-locking inactive vaults
        if self.lock_timer:
            self.lock_timer.cancel()
        if self.autoclose_minutes > 0:
            self.lock_timer = threading.Timer(self.autoclose_minutes * 60, self.auto_lock_triggered)
            self.lock_timer.daemon = True
            self.lock_timer.start()

    def auto_lock_triggered(self):
        # Handler executed when inactivity timer expires
        try:
            subprocess.run([BACKEND_SCRIPT, "emergency_dismount"], check=True)
            self.StateChanged()
        except Exception as e:
            print(f"Auto-lock execution error: {e}")

    @dbus.service.signal("org.omnicrypt.Manager", signature="")
    def StateChanged(self):
        # Signal emitted to notify active clients of state updates
        pass

    @dbus.service.method("org.omnicrypt.Manager", in_signature="", out_signature="s")
    def GetStatus(self):
        # Query active status of containers and fscrypt directories
        data = {"containers": [], "fscrypt_dirs": [], "has_active_vaults": False}
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r") as f:
                    cfg = json.load(f)
                
                for c in cfg.get("containers", []):
                    mapper = c.get("mapper")
                    image = c.get("image")
                    mount_point = c.get("mount_point")
                    luks_locked = not os.path.exists(f"/dev/mapper/{mapper}")
                    
                    if not luks_locked:
                        data["has_active_vaults"] = True

                    data["containers"].append({
                        "mapper": mapper,
                        "image": image,
                        "mount_point": mount_point,
                        "luks_locked": luks_locked
                    })

                for d in cfg.get("fscrypt_dirs", []):
                    target = d.get("path")
                    unlocked = False
                    if target and os.path.exists(target):
                        res = subprocess.run(["fscrypt", "status", target], capture_output=True, text=True)
                        if "Unlocked: true" in res.stdout or "Policy:" in res.stdout:
                            unlocked = True
                            data["has_active_vaults"] = True
                    data["fscrypt_dirs"].append({
                        "path": target,
                        "unlocked": unlocked
                    })
        except Exception as e:
            print(f"Status query error: {e}")
        return json.dumps(data)

    @dbus.service.method("org.omnicrypt.Manager", in_signature="ssssi", out_signature="i")
    def MountImageWithPassword(self, img_path, mapper_name, mount_point, password, autoclose_min):
        # Open LUKS container using secure stdin pipe and mount filesystem
        self.autoclose_minutes = autoclose_min
        os.makedirs(mount_point, exist_ok=True)
        try:
            p = subprocess.Popen(["cryptsetup", "open", img_path, mapper_name], stdin=subprocess.PIPE, text=True)
            p.communicate(input=password)
            if p.returncode != 0:
                return 1
            subprocess.run(["mount", f"/dev/mapper/{mapper_name}", mount_point], check=True)
            
            # Persist state parameters
            cfg = {"containers": [{"mapper": mapper_name, "image": img_path, "mount_point": mount_point}], "autoclose_minutes": autoclose_min}
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, "w") as f:
                json.dump(cfg, f)

            self.reset_inactivity_timer()
            self.StateChanged()
            return 0
        except Exception as e:
            print(f"Mount execution error: {e}")
            return 1

    @dbus.service.method("org.omnicrypt.Manager", in_signature="si", out_signature="i")
    def UnlockFolder(self, target_dir, password):
        # Unlock fscrypt encrypted directory via stdin password pipe
        try:
            p = subprocess.Popen(["fscrypt", "unlock", target_dir], stdin=subprocess.PIPE, text=True)
            p.communicate(input=password)
            if p.returncode != 0:
                return 1
            self.reset_inactivity_timer()
            self.StateChanged()
            return 0
        except Exception as e:
            print(f"fscrypt unlock error: {e}")
            return 1

    @dbus.service.method("org.omnicrypt.Manager", in_signature="s", out_signature="i")
    def LockFolder(self, target_dir):
        # Sync filesystem and lock fscrypt directory
        try:
            subprocess.run([BACKEND_SCRIPT, "sync_fs"], check=True)
            subprocess.run(["fscrypt", "lock", target_dir], check=True)
            self.StateChanged()
            return 0
        except Exception as e:
            print(f"Folder lock error: {e}")
            return 1

    @dbus.service.method("org.omnicrypt.Manager", in_signature="", out_signature="i")
    def EmergencyDismount(self):
        # Trigger panic button lockdown: force sync, unmount, and close crypt mappers
        try:
            if self.lock_timer:
                self.lock_timer.cancel()
            subprocess.run([BACKEND_SCRIPT, "emergency_dismount"], check=True)
            if os.path.exists(CONFIG_FILE):
                os.remove(CONFIG_FILE)
            self.StateChanged()
            return 0
        except Exception as e:
            print(f"Emergency dismount error: {e}")
            return 1

if __name__ == "__main__":
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    loop = GLib.MainLoop()
    service = OmniCryptService()
    loop.run()
