#!/usr/bin/env python3
# OmniCrypt D-Bus Service Backend
# NAZY-OS - GPL v3

import os
import json
import subprocess
import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib

BACKEND_SCRIPT = "/usr/libexec/omnicrypt/omnicrypt.sh"

class OmniCryptService(dbus.service.Object):
    def __init__(self):
        bus_name = dbus.service.BusName("org.omnicrypt.Manager", dbus.SystemBus())
        super().__init__(bus_name, "/org/omnicrypt/Manager")

    @dbus.service.signal("org.omnicrypt.Manager", signature="")
    def StateChanged(self):
        pass

    @dbus.service.method("org.omnicrypt.Manager", in_signature="", out_signature="s")
    def GetStatus(self):
        config_path = "/etc/omnicrypt/config.json"
        data = {"containers": []}
        try:
            if os.path.exists(config_path):
                with open(config_path, "r") as f:
                    cfg = json.load(f)
                for c in cfg.get("containers", []):
                    mapper = c.get("mapper")
                    image = c.get("image")
                    mount_point = c.get("mount_point")
                    
                    luks_locked = not os.path.exists(f"/dev/mapper/{mapper}")
                    
                    fscrypt_folders = []
                    if not luks_locked and os.path.exists(mount_point):
                        try:
                            res = subprocess.run(["fscrypt", "status", mount_point], capture_output=True, text=True)
                            for line in res.stdout.splitlines():
                                if "Policy:" in line or "Unlocked:" in line or "/" in line:
                                    pass
                        except Exception:
                            pass
                    
                    data["containers"].append({
                        "mapper": mapper,
                        "image": image,
                        "mount_point": mount_point,
                        "luks_locked": luks_locked,
                        "fscrypt_folders": fscrypt_folders
                    })
        except Exception as e:
            print(f"Error getting status: {e}")
        return json.dumps(data)

    @dbus.service.method("org.omnicrypt.Manager", in_signature="ssss", out_signature="i")
    def MountImageWithPassword(self, img_path, mapper_name, mount_point, password):
        os.makedirs(mount_point, exist_ok=True)
        try:
            p = subprocess.Popen(["cryptsetup", "open", img_path, mapper_name], stdin=subprocess.PIPE, text=True)
            p.communicate(input=password)
            if p.returncode != 0:
                return 1
            subprocess.run(["mount", f"/dev/mapper/{mapper_name}", mount_point], check=True)
            self.StateChanged()
            return 0
        except Exception as e:
            print(f"Mount error: {e}")
            return 1

    @dbus.service.method("org.omnicrypt.Manager", in_signature="sss", out_signature="i")
    def UnlockFolderAdvanced(self, target_dir, method, key_file, password, autoclose_min=10):
        # Implementation placeholder
        self.StateChanged()
        return 0

    @dbus.service.method("org.omnicrypt.Manager", in_signature="s", out_signature="i")
    def LockFolder(self, target_dir):
        try:
            subprocess.run([BACKEND_SCRIPT, "sync_fs"], check=True)
            subprocess.run(["fscrypt", "lock", target_dir], check=True)
            self.StateChanged()
            return 0
        except Exception as e:
            print(f"Lock error: {e}")
            return 1

    @dbus.service.method("org.omnicrypt.Manager", in_signature="", out_signature="i")
    def EmergencyDismount(self):
        try:
            subprocess.run([BACKEND_SCRIPT, "emergency_dismount"], check=True)
            self.StateChanged()
            return 0
        except Exception as e:
            print(f"Emergency error: {e}")
            return 1

if __name__ == "__main__":
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    loop = GLib.MainLoop()
    service = OmniCryptService()
    loop.run()
