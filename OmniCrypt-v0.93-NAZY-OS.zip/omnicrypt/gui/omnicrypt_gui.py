#!/usr/bin/env python3
# OmniCrypt GTK4 UI v.0.93 – German Interface with Dynamic Tray & Advanced Security Management
# Developer: NAZY-OS
# License: GNU GPL v3

import json
import os
import sys
import threading
import subprocess
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gio", "2.0")
gi.require_version("Notify", "0.7")

from gi.repository import Gio, Gtk, GLib, Notify
from pydbus import SystemBus

HAVE_APPINDICATOR = False
try:
    gi.require_version("AppIndicator3", "0.1")
    from gi.repository import AppIndicator3
    HAVE_APPINDICATOR = True
except (ValueError, ImportError):
    pass

Notify.init("OmniCrypt")

class OmniCryptWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_title("OmniCrypt Pro v.0.93 – NAZY-OS (Klassischer Win7 Stil)")
        self.set_default_size(1000, 700)
        
        # Startet minimiert im System-Tray / ausgeblendet
        self.set_visible(False)

        try:
            self.bus = SystemBus()
            self.proxy = self.bus.get("org.omnicrypt.Manager")
            self.proxy.onStateChanged = lambda: GLib.idle_add(self.refresh_status)
        except Exception:
            self.proxy = None

        root_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.set_child(root_box)

        # 1. Klassische Windows 7 Menüleiste
        menubar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        menubar.add_css_class("toolbar")
        menubar.set_margin_start(4)
        menubar.set_margin_end(4)
        menubar.set_margin_top(4)
        menubar.set_margin_bottom(4)
        root_box.append(menubar)

        # Datei Menü
        file_btn = Gtk.MenuButton(label="Datei")
        file_popover = Gtk.Popover()
        file_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        
        btn_open_img = Gtk.Button(label="LUKS-Image durchsuchen...", xalign=0)
        btn_open_img.add_css_class("flat")
        btn_open_img.connect("clicked", lambda w: self.on_select_image_dialog())
        file_box.append(btn_open_img)

        btn_quit_app = Gtk.Button(label="Beenden", xalign=0)
        btn_quit_app.add_css_class("flat")
        btn_quit_app.connect("clicked", lambda w: Gtk.Application.quit(self.get_application()))
        file_box.append(btn_quit_app)

        file_popover.set_child(file_box)
        file_btn.set_popover(file_popover)
        menubar.append(file_btn)

        # Sicherheit & Aktionen Menü
        sec_btn = Gtk.MenuButton(label="Sicherheit & Aktionen")
        sec_popover = Gtk.Popover()
        sec_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)

        btn_panic = Gtk.Button(label="🚨 Notfall-Lockdown (Ctrl+Shift+L)", xalign=0)
        btn_panic.add_css_class("flat")
        btn_panic.connect("clicked", lambda w: self.on_emergency_clicked())
        sec_box.append(btn_panic)

        sec_popover.set_child(sec_box)
        sec_btn.set_popover(sec_popover)
        menubar.append(sec_btn)

        # Hilfe Menü
        help_btn = Gtk.MenuButton(label="Hilfe")
        help_popover = Gtk.Popover()
        help_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        btn_about = Gtk.Button(label="Über OmniCrypt v.0.93", xalign=0)
        btn_about.add_css_class("flat")
        btn_about.connect("clicked", lambda w: self.set_status("OmniCrypt Pro v.0.93 (NAZY-OS) - Sicherer LUKS & fscrypt Manager."))
        help_box.append(btn_about)
        help_popover.set_child(help_box)
        help_btn.set_popover(help_popover)
        menubar.append(help_btn)

        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        root_box.append(sep)

        # 2. Notebook / Tabs Komponente
        self.notebook = Gtk.Notebook()
        self.notebook.set_vexpand(True)
        self.notebook.set_hexpand(True)
        root_box.append(self.notebook)

        # --- TAB 1: Dashboard & Status ---
        tab1_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        tab1_box.set_margin_top(16)
        tab1_box.set_margin_bottom(16)
        tab1_box.set_margin_start(16)
        tab1_box.set_margin_end(16)

        action_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        tab1_box.append(action_bar)

        btn_ref = Gtk.Button(label="Status aktualisieren")
        btn_ref.add_css_class("flat")
        btn_ref.connect("clicked", lambda w: self.refresh_status())
        action_bar.append(btn_ref)

        btn_emergency = Gtk.Button(label="🚨 NOTFALL-LOCKDOWN (Ctrl+Shift+L)")
        btn_emergency.add_css_class("destructive-action")
        btn_emergency.connect("clicked", lambda w: self.on_emergency_clicked())
        action_bar.append(btn_emergency)

        scrolled = Gtk.ScrolledWindow(vexpand=True, hexpand=True)
        scrolled.add_css_class("card")
        tab1_box.append(scrolled)

        self.list_box = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        scrolled.set_child(self.list_box)
        
        self.notebook.append_page(tab1_box, Gtk.Label(label="Dashboard & Status"))

        # --- TAB 2: LUKS Mount Manager ---
        tab2_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        tab2_box.set_margin_top(24)
        tab2_box.set_margin_bottom(24)
        tab2_box.set_margin_start(24)
        tab2_box.set_margin_end(24)

        form_grid = Gtk.Grid()
        form_grid.set_row_spacing(12)
        form_grid.set_column_spacing(12)
        tab2_box.append(form_grid)

        form_grid.attach(Gtk.Label(label="LUKS Image-Datei:", xalign=0), 0, 0, 1, 1)
        self.entry_image = Gtk.Entry()
        self.entry_image.set_hexpand(True)
        form_grid.attach(self.entry_image, 1, 0, 1, 1)

        btn_browse_img = Gtk.Button(label="Durchsuchen...")
        btn_browse_img.connect("clicked", lambda w: self.on_select_image_dialog())
        form_grid.attach(btn_browse_img, 2, 0, 1, 1)

        form_grid.attach(Gtk.Label(label="Mapper-Name:", xalign=0), 0, 1, 1, 1)
        self.entry_mapper = Gtk.Entry(text="omnicrypt_secure")
        form_grid.attach(self.entry_mapper, 1, 1, 2, 1)

        form_grid.attach(Gtk.Label(label="Einhängepunkt (Mount):", xalign=0), 0, 2, 1, 1)
        self.entry_mount = Gtk.Entry(text="/mnt/omnicrypt_secure")
        form_grid.attach(self.entry_mount, 1, 2, 2, 1)

        form_grid.attach(Gtk.Label(label="Passwort (Stdin):", xalign=0), 0, 3, 1, 1)
        self.entry_pass = Gtk.PasswordEntry()
        form_grid.attach(self.entry_pass, 1, 3, 2, 1)

        btn_mount_exec = Gtk.Button(label="LUKS-Container öffnen & einhängen")
        btn_mount_exec.add_css_class("suggested-action")
        btn_mount_exec.connect("clicked", self.on_mount_clicked)
        tab2_box.append(btn_mount_exec)

        self.notebook.append_page(tab2_box, Gtk.Label(label="LUKS Mount"))

        # --- TAB 3: fscrypt Folder Manager ---
        tab3_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        tab3_box.set_margin_top(24)
        tab3_box.set_margin_bottom(24)
        tab3_box.set_margin_start(24)
        tab3_box.set_margin_end(24)

        fs_grid = Gtk.Grid()
        fs_grid.set_row_spacing(12)
        fs_grid.set_column_spacing(12)
        tab3_box.append(fs_grid)

        fs_grid.attach(Gtk.Label(label="Zielverzeichnis:", xalign=0), 0, 0, 1, 1)
        self.entry_fscrypt_dir = Gtk.Entry()
        self.entry_fscrypt_dir.set_hexpand(True)
        fs_grid.attach(self.entry_fscrypt_dir, 1, 0, 1, 1)

        btn_browse_dir = Gtk.Button(label="Ordner wählen...")
        btn_browse_dir.connect("clicked", lambda w: self.on_select_folder_dialog())
        fs_grid.attach(btn_browse_dir, 2, 0, 1, 1)

        fs_grid.attach(Gtk.Label(label="Passwort / Schlüssel:", xalign=0), 0, 1, 1, 1)
        self.entry_fscrypt_pass = Gtk.PasswordEntry()
        fs_grid.attach(self.entry_fscrypt_pass, 1, 1, 2, 1)

        fs_action_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        tab3_box.append(fs_action_box)

        btn_fs_unlock = Gtk.Button(label="fscrypt-Ordner entsperren")
        btn_fs_unlock.add_css_class("suggested-action")
        btn_fs_unlock.connect("clicked", self.on_unlock_fscrypt_clicked)
        fs_action_box.append(btn_fs_unlock)

        btn_fs_lock = Gtk.Button(label="fscrypt-Ordner sperren")
        btn_fs_lock.add_css_class("destructive-action")
        btn_fs_lock.connect("clicked", self.on_lock_fscrypt_clicked)
        fs_action_box.append(btn_fs_lock)

        self.notebook.append_page(tab3_box, Gtk.Label(label="fscrypt Ordner"))

        # --- TAB 4: Options & Settings ---
        tab4_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        tab4_box.set_margin_top(24)
        tab4_box.set_margin_bottom(24)
        tab4_box.set_margin_start(24)
        tab4_box.set_margin_end(24)

        opt_grid = Gtk.Grid()
        opt_grid.set_row_spacing(12)
        opt_grid.set_column_spacing(12)
        tab4_box.append(opt_grid)

        opt_grid.attach(Gtk.Label(label="Auto-Close Inaktivitäts-Timer (Minuten):", xalign=0), 0, 0, 1, 1)
        self.spin_autoclose = Gtk.SpinButton.new_with_range(1, 120, 1)
        self.spin_autoclose.set_value(15)
        opt_grid.attach(self.spin_autoclose, 1, 0, 1, 1)

        opt_grid.attach(Gtk.Label(label="Audio-Hinweise & System-Bell:", xalign=0), 0, 1, 1, 1)
        self.check_audio = Gtk.CheckButton(label="Akustische Warnsignale / System-Bell aktivieren")
        self.check_audio.set_active(True)
        opt_grid.attach(self.check_audio, 1, 1, 1, 1)

        self.notebook.append_page(tab4_box, Gtk.Label(label="Optionen"))

        # Statusleiste unten
        self.status_label = Gtk.Label(label="System bereit. Hotkeys aktiv: [Ctrl+Alt+G] Fenster umschalten, [Ctrl+Shift+L] Notfall-Panic.", xalign=0)
        self.status_label.set_margin_start(8)
        self.status_label.set_margin_bottom(4)
        root_box.append(self.status_label)

        self.setup_system_tray()
        self.setup_global_hotkeys()
        self.refresh_status()

        GLib.idle_add(self.force_render_fix)

    def force_render_fix(self):
        self.queue_resize()
        self.queue_draw()
        return False

    def set_status(self, text):
        self.status_label.set_text(f"Info: {text}")
        if self.check_audio.get_active():
            print("", end="", flush=True)

    def refresh_status(self):
        while (row := self.list_box.get_row_at_index(0)):
            self.list_box.remove(row)
        if not self.proxy:
            self.list_box.append(Gtk.Label(label="Keine D-Bus Verbindung (Dienst offline)."))
            return
        try:
            data = json.loads(self.proxy.GetStatus())
            has_active = data.get("has_active_vaults", False)
            self.update_tray_icon_state(has_active)
        except Exception:
            return

        for c in data.get("containers", []):
            frame = Gtk.Frame()
            frame.add_css_class("card")
            
            # Rechtsklick-Kontextmenü Simulation
            gest = Gtk.GestureClick.new()
            gest.set_button(3)
            gest.connect("pressed", lambda g, n, x, y, mapper=c['mapper']: self.on_container_right_click(mapper))
            frame.add_controller(gest)

            f_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
            frame.set_child(f_box)
            status_text = "Gesichert 🔒" if c['luks_locked'] else "Entsperrt 🔓"
            info_label = Gtk.Label(label=f"Container: {c['mapper']}
Image: {c['image']}
Einhängepunkt: {c['mount_point']} | Status: {status_text} (Rechtsklick für Optionen)", xalign=0)
            f_box.append(info_label)
            self.list_box.append(frame)

    def on_container_right_click(self, mapper_name):
        self.set_status(f"Rechtsklick-Kontextaktion ausgelöst für: {mapper_name}")

    def update_tray_icon_state(self, is_unlocked):
        if not HAVE_APPINDICATOR or not hasattr(self, 'indicator'):
            return
        if is_unlocked:
            self.indicator.set_icon_full("system-lock-screen-symbolic", "OmniCrypt (ENTSPERRT / AKTIV)")
            self.indicator.set_title("OmniCrypt [ENTSPERRT]")
        else:
            self.indicator.set_icon_full("dialog-password-symbolic", "OmniCrypt (GESICHERT / GESPERRT)")
            self.indicator.set_title("OmniCrypt [GESICHERT]")

    def setup_system_tray(self):
        if not HAVE_APPINDICATOR:
            return
        try:
            self.indicator = AppIndicator3.Indicator.new(
                "omnicrypt-indicator",
                "dialog-password-symbolic",
                AppIndicator3.IndicatorCategory.APPLICATION_STATUS
            )
            self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)
            self.indicator.set_menu(self.build_tray_menu())
        except Exception as e:
            print(f"Fehler beim Initialisieren des System-Trays: {e}")

    def build_tray_menu(self):
        menu = Gtk.Menu()
        
        item_title = Gtk.MenuItem(label="OmniCrypt Pro v.0.93 (NAZY-OS)")
        item_title.set_sensitive(False)
        menu.append(item_title)
        menu.append(Gtk.SeparatorMenuItem())
        
        item_toggle = Gtk.MenuItem(label="Fenster umschalten (Ctrl+Alt+G)")
        item_toggle.connect("activate", lambda w: self.toggle_window_visibility())
        menu.append(item_toggle)

        item_open_luks = Gtk.MenuItem(label="LUKS-Image einhängen...")
        item_open_luks.connect("activate", lambda w: self.toggle_window_visibility())
        menu.append(item_open_luks)

        menu.append(Gtk.SeparatorMenuItem())

        item_emergency = Gtk.MenuItem(label="🚨 NOTFALL-LOCKDOWN (Ctrl+Shift+L)")
        item_emergency.connect("activate", lambda w: self.on_emergency_clicked())
        menu.append(item_emergency)
        
        menu.append(Gtk.SeparatorMenuItem())

        item_quit = Gtk.MenuItem(label="OmniCrypt beenden")
        item_quit.connect("activate", lambda w: Gtk.Application.quit(self.get_application()))
        menu.append(item_quit)

        menu.show_all()
        return menu

    def on_select_image_dialog(self):
        dialog = Gtk.FileDialog.new()
        dialog.set_title("LUKS-Container Image auswählen")
        dialog.open(self, None, self.on_file_selected_cb)

    def on_file_selected_cb(self, dialog, result):
        try:
            file = dialog.open_finish(result)
            if file:
                path = file.get_path()
                self.entry_image.set_text(path)
                self.set_status(f"Ausgewähltes Image: {path}")
        except Exception as e:
            print(f"Dateiauswahl-Fehler: {e}")

    def on_select_folder_dialog(self):
        dialog = Gtk.FileDialog.new()
        dialog.set_title("fscrypt Zielordner auswählen")
        dialog.select_folder(self, None, self.on_folder_selected_cb)

    def on_folder_selected_cb(self, dialog, result):
        try:
            folder = dialog.select_folder_finish(result)
            if folder:
                path = folder.get_path()
                self.entry_fscrypt_dir.set_text(path)
                self.set_status(f"Ausgewählter Ordner: {path}")
        except Exception as e:
            print(f"Ordnerauswahl-Fehler: {e}")

    def on_mount_clicked(self, btn):
        img = self.entry_image.get_text()
        mapper = self.entry_mapper.get_text()
        mount = self.entry_mount.get_text()
        pwd = self.entry_pass.get_text()
        autoclose_min = int(self.spin_autoclose.get_value())
        if not img or not mapper or not mount:
            self.set_status("Bitte alle Mount-Parameter ausfüllen.")
            return
        if self.proxy:
            def do_mount():
                res = self.proxy.MountImageWithPassword(img, mapper, mount, pwd, autoclose_min)
                if res == 0:
                    GLib.idle_add(self.set_status, f"Container {mapper} erfolgreich unter {mount} eingehängt.")
                else:
                    GLib.idle_add(self.set_status, f"Fehler beim Einhängen von {mapper}.")
            threading.Thread(target=do_mount, daemon=True).start()

    def on_unlock_fscrypt_clicked(self, btn):
        directory = self.entry_fscrypt_dir.get_text()
        pwd = self.entry_fscrypt_pass.get_text()
        if not directory:
            self.set_status("Bitte ein Zielverzeichnis angeben.")
            return
        if self.proxy:
            def do_unlock():
                res = self.proxy.UnlockFolder(directory, pwd)
                if res == 0:
                    GLib.idle_add(self.set_status, f"fscrypt-Ordner entsperrt: {directory}")
                else:
                    GLib.idle_add(self.set_status, f"Fehler beim Entsperren des Ordners.")
            threading.Thread(target=do_unlock, daemon=True).start()

    def on_lock_fscrypt_clicked(self, btn):
        directory = self.entry_fscrypt_dir.get_text()
        if not directory:
            self.set_status("Bitte einen zu sperrenden Ordner angeben.")
            return
        if self.proxy:
            def do_lock():
                self.proxy.LockFolder(directory)
                GLib.idle_add(self.set_status, f"fscrypt-Ordner gesperrt: {directory}")
            threading.Thread(target=do_lock, daemon=True).start()

    def on_emergency_clicked(self):
        if self.proxy:
            def do_emergency():
                self.proxy.EmergencyDismount()
                GLib.idle_add(self.set_status, "🚨 NOTFALL-LOCKDOWN AUSGELÖST!")
                GLib.idle_add(lambda: Notify.Notification.new("OmniCrypt SICHERHEITS-ALARM v.0.93", "Notfall-Lockdown erfolgreich ausgeführt!", "dialog-warning").show())
            threading.Thread(target=do_emergency, daemon=True).start()

    def toggle_window_visibility(self):
        if self.is_visible():
            self.set_visible(False)
        else:
            self.set_visible(True)
            self.present()
            self.queue_resize()
            self.queue_draw()

    def setup_global_hotkeys(self):
        key_controller = Gtk.EventControllerKey.new()
        key_controller.connect("key-pressed", self.on_key_pressed)
        self.add_controller(key_controller)

    def on_key_pressed(self, controller, keyval, keycode, state):
        if keyval in (ord('g'), ord('G')) and (state & 4) and (state & 8):
            self.toggle_window_visibility()
            return True
        if keyval in (ord('l'), ord('L')) and (state & 4) and (state & 1):
            self.on_emergency_clicked()
            return True
        return False

class OmniCryptApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.omnicrypt.Manager")
    def do_activate(self):
        win = OmniCryptWindow(application=self)
        win.present()

if __name__ == "__main__":
    sys.exit(OmniCryptApp().run(sys.argv))
