#!/usr/bin/env bash
# OmniCrypt Backend Helper
# NAZY-OS - GPL v3

CONFIG_FILE="/etc/omnicrypt/config.json"

backend_sync_filesystem() {
    sync
    return 0
}

backend_update_config() {
    local new_json="$1"
    if [[ $EUID -ne 0 ]]; then
        echo "Root privileges required." >&2
        return 1
    fi
    mkdir -p "$(dirname "$CONFIG_FILE")"
    echo "$new_json" > "$CONFIG_FILE"
    chmod 644 "$CONFIG_FILE"
}

backend_emergency_dismount_all() {
    sync
    for dir in $(fscrypt status 2>/dev/null | grep -oE '/[^ ]+'); do
        fscrypt lock "$dir" 2>/dev/null || true
    done

    if [[ -d "/run/omnicrypt" ]]; then
        for mount_pt in /mnt/*; do
            if mountpoint -q "$mount_pt"; then
                umount -f "$mount_pt" 2>/dev/null || true
            fi
        done
    fi

    for mapper in /dev/mapper/omnicrypt_*; do
        if [[ -e "$mapper" ]]; then
            local name=$(basename "$mapper")
            cryptsetup close "$name" 2>/dev/null || true
        fi
    done
    return 0
}

case "$1" in
    sync_fs) backend_sync_filesystem ;;
    update_config) backend_update_config "$2" ;;
    emergency_dismount) backend_emergency_dismount_all ;;
    *) echo "Invalid command"; exit 1 ;;
esac
