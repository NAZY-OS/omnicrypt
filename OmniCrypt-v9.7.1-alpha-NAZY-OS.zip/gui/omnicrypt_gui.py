#!/usr/bin/env python3
# OmniCrypt GTK4 UI v.9.7.1 – English Interface with Standardized Exception & Infobox Error Handling
# Developer: NAZY-OS
# License: GNU GPL v3

import json
import os
import sys
import threading
import subprocess
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gio", "2.0")
gi.require_version("Notify", "0.7")

from gi.repository import Gio, Gtk, GLib, Notify
from pydbus import SystemBus

HAVE_APPINDICATOR = False
try:
    gi.require_version("AppIndicator3", "0.1")
    from gi.repository import AppIndicator3
    HAVE_APPINDICATOR = True
except (ValueError, ImportError):
    pass

Notify.init("OmniCrypt")

class OmniCryptErrorDialog:
    # Standardized norm-compliant error infobox helper using Gtk.AlertDialog
    @staticmethod
    def show_error(parent_window, title, message):
        def _trigger():
            dialog = Gtk.AlertDialog.new(title)
            dialog.set_detail(message)
            dialog.set_buttons(["OK"])
            dialog.show(parent_window)
        GLib.idle_add(_trigger)

class OmniCryptWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_title("OmniCrypt Pro v.9.7.1 – NAZY-OS (Classic Win7 Style)")
        self.set_default_size(1000, 700)
        self.set_visible(False)

        try:
            self.bus = SystemBus()
            self.proxy = self.bus.get("org.omnicrypt.Manager")
            self.proxy.onStateChanged = lambda: GLib.idle_add(self.refresh_status)
        except Exception as err:
            OmniCryptErrorDialog.show_error(self, "D-Bus Connection Error", f"Failed to connect to OmniCrypt system service:\n{str(err)}")
            self.proxy = None

        root_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.set_child(root_box)

        # Menu bar
        menubar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        menubar.add_css_class("toolbar")
        root_box.append(menubar)

        file_btn = Gtk.MenuButton(label="File")
        file_popover = Gtk.Popover()
        file_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        
        btn_open_img = Gtk.Button(label="Browse LUKS Image...", xalign=0)
        btn_open_img.add_css_class("flat")
        btn_open_img.connect("clicked", lambda w: self.on_select_image_dialog())
        file_box.append(btn_open_img)

        btn_quit_app = Gtk.Button(label="Exit", xalign=0)
        btn_quit_app.add_css_class("flat")
        btn_quit_app.connect("clicked", lambda w: Gtk.Application.quit(self.get_application()))
        file_box.append(btn_quit_app)

        file_popover.set_child(file_box)
        file_btn.set_popover(file_popover)
        menubar.append(file_btn)

        # Notebook / Tabs
        self.notebook = Gtk.Notebook()
        self.notebook.set_vexpand(True)
        self.notebook.set_hexpand(True)
        root_box.append(self.notebook)

        # Tab 1: Dashboard
        tab1_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=16, margin_bottom=16, margin_start=16, margin_end=16)
        scrolled = Gtk.ScrolledWindow(vexpand=True, hexpand=True)
        scrolled.add_css_class("card")
        tab1_box.append(scrolled)
        self.list_box = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        scrolled.set_child(self.list_box)
        self.notebook.append_page(tab1_box, Gtk.Label(label="Dashboard & Status"))

        # Tab 2: LUKS Mount
        tab2_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, margin_top=24, margin_bottom=24, margin_start=24, margin_end=24)
        form_grid = Gtk.Grid(row_spacing=12, column_spacing=12)
        tab2_box.append(form_grid)

        form_grid.attach(Gtk.Label(label="LUKS Image File:", xalign=0), 0, 0, 1, 1)
        self.entry_image = Gtk.Entry()
        self.entry_image.set_hexpand(True)
        form_grid.attach(self.entry_image, 1, 0, 1, 1)

        btn_browse_img = Gtk.Button(label="Browse...")
        btn_browse_img.connect("clicked", lambda w: self.on_select_image_dialog())
        form_grid.attach(btn_browse_img, 2, 0, 1, 1)

        form_grid.attach(Gtk.Label(label="Mapper Name:", xalign=0), 0, 1, 1, 1)
        self.entry_mapper = Gtk.Entry(text="omnicrypt_secure")
        form_grid.attach(self.entry_mapper, 1, 1, 2, 1)

        form_grid.attach(Gtk.Label(label="Mount Point:", xalign=0), 0, 2, 1, 1)
        self.entry_mount = Gtk.Entry(text="/mnt/omnicrypt_secure")
        form_grid.attach(self.entry_mount, 1, 2, 2, 1)

        form_grid.attach(Gtk.Label(label="Password (Stdin):", xalign=0), 0, 3, 1, 1)
        self.entry_pass = Gtk.PasswordEntry()
        form_grid.attach(self.entry_pass, 1, 3, 2, 1)

        btn_mount_exec = Gtk.Button(label="Open & Mount LUKS Container")
        btn_mount_exec.add_css_class("suggested-action")
        btn_mount_exec.connect("clicked", self.on_mount_clicked)
        tab2_box.append(btn_mount_exec)

        self.notebook.append_page(tab2_box, Gtk.Label(label="LUKS Mount"))

        # Status Bar
        self.status_label = Gtk.Label(label="System ready (v.9.7.1). Hotkeys active: [Ctrl+Alt+G] Toggle, [Ctrl+Shift+L] Panic.", xalign=0)
        self.status_label.set_margin_start(8)
        self.status_label.set_margin_bottom(4)
        root_box.append(self.status_label)

        self.setup_system_tray()
        self.setup_global_hotkeys()
        self.refresh_status()
        GLib.idle_add(self.force_render_fix)

    def force_render_fix(self):
        self.queue_resize()
        self.queue_draw()
        return False

    def set_status(self, text):
        self.status_label.set_text(f"Info: {text}")

    def refresh_status(self):
        while (row := self.list_box.get_row_at_index(0)):
            self.list_box.remove(row)
        if not self.proxy:
            return
        try:
            data = json.loads(self.proxy.GetStatus())
            has_active = data.get("has_active_vaults", False)
            self.update_tray_icon_state(has_active)
        except Exception as err:
            OmniCryptErrorDialog.show_error(self, "Status Refresh Error", f"Failed to retrieve container status from system service:\n{str(err)}")
            return

        for c in data.get("containers", []):
            frame = Gtk.Frame(label=f"Container: {c['mapper']}")
            frame.add_css_class("card")
            f_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
            frame.set_child(f_box)
            status_text = "Locked 🔒" if c['luks_locked'] else "Unlocked 🔓"
            info_label = Gtk.Label(label=f"Image: {c['image']}\nMount Point: {c['mount_point']} | Status: {status_text}", xalign=0)
            f_box.append(info_label)
            self.list_box.append(frame)

    def update_tray_icon_state(self, is_unlocked):
        if not HAVE_APPINDICATOR or not hasattr(self, 'indicator'):
            return
        if is_unlocked:
            self.indicator.set_icon_full("system-lock-screen-symbolic", "OmniCrypt (UNLOCKED)")
            self.indicator.set_title("OmniCrypt [UNLOCKED]")
        else:
            self.indicator.set_icon_full("dialog-password-symbolic", "OmniCrypt (SECURE)")
            self.indicator.set_title("OmniCrypt [SECURE]")

    def setup_system_tray(self):
        if not HAVE_APPINDICATOR:
            return
        try:
            self.indicator = AppIndicator3.Indicator.new(
                "omnicrypt-indicator",
                "dialog-password-symbolic",
                AppIndicator3.IndicatorCategory.APPLICATION_STATUS
            )
            self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)
            menu = Gtk.Menu()
            item_toggle = Gtk.MenuItem(label="Toggle Window (Ctrl+Alt+G)")
            item_toggle.connect("activate", lambda w: self.toggle_window_visibility())
            menu.append(item_toggle)
            menu.append(Gtk.SeparatorMenuItem())
            item_quit = Gtk.MenuItem(label="Quit OmniCrypt")
            item_quit.connect("activate", lambda w: Gtk.Application.quit(self.get_application()))
            menu.append(item_quit)
            menu.show_all()
            self.indicator.set_menu(menu)
        except Exception as err:
            OmniCryptErrorDialog.show_error(self, "System Tray Error", f"Failed to initialize system tray indicator:\n{str(err)}")

    def on_select_image_dialog(self):
        try:
            dialog = Gtk.FileDialog.new()
            dialog.set_title("Select LUKS Container Image")
            dialog.open(self, None, self.on_file_selected_cb)
        except Exception as err:
            OmniCryptErrorDialog.show_error(self, "File Dialog Error", f"Could not open file picker dialog:\n{str(err)}")

    def on_file_selected_cb(self, dialog, result):
        try:
            file = dialog.open_finish(result)
            if file:
                path = file.get_path()
                self.entry_image.set_text(path)
                self.set_status(f"Selected image: {path}")
        except Exception as err:
            OmniCryptErrorDialog.show_error(self, "Selection Error", f"Failed to retrieve selected file path:\n{str(err)}")

    def on_mount_clicked(self, btn):
        img = self.entry_image.get_text()
        mapper = self.entry_mapper.get_text()
        mount = self.entry_mount.get_text()
        pwd = self.entry_pass.get_text()
        if not img or not mapper or not mount:
            OmniCryptErrorDialog.show_error(self, "Validation Error", "Please fill in all required mount parameters (Image, Mapper Name, Mount Point).")
            return
        if self.proxy:
            def do_mount():
                try:
                    res = self.proxy.MountImageWithPassword(img, mapper, mount, pwd, 15)
                    if res == 0:
                        GLib.idle_add(self.set_status, f"Container {mapper} successfully mounted at {mount}.")
                    else:
                        GLib.idle_add(OmniCryptErrorDialog.show_error, self, "Mount Execution Error", f"Cryptsetup or mount operation failed for container '{mapper}'.")
                except Exception as err:
                    GLib.idle_add(OmniCryptErrorDialog.show_error, self, "Remote Service Error", f"D-Bus call failed during mount execution:\n{str(err)}")
            threading.Thread(target=do_mount, daemon=True).start()

    def toggle_window_visibility(self):
        if self.is_visible():
            self.set_visible(False)
        else:
            self.set_visible(True)
            self.present()
            self.queue_resize()
            self.queue_draw()

    def setup_global_hotkeys(self):
        key_controller = Gtk.EventControllerKey.new()
        key_controller.connect("key-pressed", self.on_key_pressed)
        self.add_controller(key_controller)

    def on_key_pressed(self, controller, keyval, keycode, state):
        if keyval in (ord('g'), ord('G')) and (state & 4) and (state & 8):
            self.toggle_window_visibility()
            return True
        return False

class OmniCryptApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.omnicrypt.Manager")
    def do_activate(self):
        win = OmniCryptWindow(application=self)
        win.present()

if __name__ == "__main__":
    sys.exit(OmniCryptApp().run(sys.argv))
