#!/usr/bin/env python3
# OmniCrypt D-Bus Service Backend v.9.7.1 – Standardized Exception Handling
# Developer: NAZY-OS
# License: GNU GPL v3

import os
import json
import subprocess
import threading
import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib

BACKEND_SCRIPT = "/usr/libexec/omnicrypt/omnicrypt.sh"
CONFIG_FILE = "/etc/omnicrypt/config.json"

class OmniCryptService(dbus.service.Object):
    def __init__(self):
        bus_name = dbus.service.BusName("org.omnicrypt.Manager", dbus.SystemBus())
        super().__init__(bus_name, "/org/omnicrypt/Manager")
        self.lock_timer = None
        self.autoclose_minutes = 15

    @dbus.service.signal("org.omnicrypt.Manager", signature="")
    def StateChanged(self):
        pass

    @dbus.service.method("org.omnicrypt.Manager", in_signature="", out_signature="s")
    def GetStatus(self):
        data = {"containers": [], "has_active_vaults": False}
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r") as f:
                    cfg = json.load(f)
                for c in cfg.get("containers", []):
                    mapper = c.get("mapper")
                    image = c.get("image")
                    mount_point = c.get("mount_point")
                    luks_locked = not os.path.exists(f"/dev/mapper/{mapper}")
                    if not luks_locked:
                        data["has_active_vaults"] = True
                    data["containers"].append({
                        "mapper": mapper,
                        "image": image,
                        "mount_point": mount_point,
                        "luks_locked": luks_locked
                    })
        except Exception as err:
            print(f"[OmniCrypt Error] GetStatus exception: {str(err)}")
        return json.dumps(data)

    @dbus.service.method("org.omnicrypt.Manager", in_signature="ssssi", out_signature="i")
    def MountImageWithPassword(self, img_path, mapper_name, mount_point, password, autoclose_min):
        try:
            os.makedirs(mount_point, exist_ok=True)
            p = subprocess.Popen(["cryptsetup", "open", img_path, mapper_name], stdin=subprocess.PIPE, text=True, stderr=subprocess.PIPE)
            _, stderr_data = p.communicate(input=password)
            if p.returncode != 0:
                print(f"[OmniCrypt Error] cryptsetup failed: {stderr_data}")
                return 1
            
            mount_res = subprocess.run(["mount", f"/dev/mapper/{mapper_name}", mount_point], capture_output=True, text=True)
            if mount_res.returncode != 0:
                print(f"[OmniCrypt Error] mount failed: {mount_res.stderr}")
                return 1

            cfg = {"containers": [{"mapper": mapper_name, "image": img_path, "mount_point": mount_point}], "autoclose_minutes": autoclose_min}
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, "w") as f:
                json.dump(cfg, f)

            self.StateChanged()
            return 0
        except Exception as err:
            print(f"[OmniCrypt Exception] MountImageWithPassword error: {str(err)}")
            return 1

if __name__ == "__main__":
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    loop = GLib.MainLoop()
    service = OmniCryptService()
    loop.run()
