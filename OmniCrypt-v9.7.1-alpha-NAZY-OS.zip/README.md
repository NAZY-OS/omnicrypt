<div align="center">

  <h1>🔒 OmniCrypt</h1>
  <p><strong>Professional-grade LUKS container & fscrypt manager for Linux (NAZY-OS) – v.9.7.1</strong></p>

  <p>
    <img src="omnicrypt.svg" width="128" height="128" alt="OmniCrypt Logo">
  </p>

  <p>
    <img src="https://img.shields.io/badge/version-v.9.7.1-blue.svg" alt="Version">
    <img src="https://img.shields.io/badge/license-GPL--3.0--or--later-blue.svg" alt="License">
    <img src="https://img.shields.io/badge/toolkit-GTK4%2FAdwaita-success.svg" alt="GTK4">
    <img src="https://img.shields.io/badge/error__handling-Standardized-informational.svg" alt="Error Handling">
  </p>

</div>

---

## 📖 Table of Contents
- [Features](#-features)
- [Architecture & Tech Stack](#-architecture--tech-stack)
- [Standardized Error Handling (v.9.7.1)](#-standardized-error-handling-v971)
- [Installation Guide](#-installation-guide)

---

## ✨ Features (v.9.7.1)

* **🔐 Secure Password Handling:** Passwords pass through secure stdin pipes and are never stored persistently on disk.
* **⚠️ Standardized Exception & Infobox Error Handling:** All backend errors and UI exceptions are caught and reported cleanly through standard GNOME/GTK Adwaita dialog boxes with precise English error descriptions.
* **🗂️ Classic Windows 7 Aesthetic & Menu Bar:** Classic window style with a native menu bar and tab navigation.
* **📁 Image & Folder Management:** LUKS sparse containers and `fscrypt` directory locking/unlocking.
* **⏱️ Auto-Close Timer & System Tray:** Multi-state dynamic tray integration and configurable inactivity timers.

---

## 🛠️ Installation & Requirements
* **Arch Linux / Fedora / Ubuntu / Debian:** Install dependencies via your package manager and deploy via Meson/Ninja.
